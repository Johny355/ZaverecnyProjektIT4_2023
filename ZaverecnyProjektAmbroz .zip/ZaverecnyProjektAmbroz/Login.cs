﻿using System;
using System.Data.SqlClient;
using System.Security.Cryptography;
using System.Security.Policy;
using System.Text;
using System.Windows.Forms;

namespace ZaverecnyProjektAmbroz
{
    public partial class Login : Form
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public Login()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // ověření uživatelského jména a hesla
            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                try
                {
                    connection.Open();
                    string username = textBox1.Text;
                    string password = textBox2.Text;
                    if (string.IsNullOrEmpty(username) || string.IsNullOrEmpty(password))
                    {
                        MessageBox.Show("Please enter a valid username and password.");
                        return;
                    }
                    // zahashování hesla uživatele
                    string hashedPassword = HashPassword(password);
                    using (SqlCommand command = new SqlCommand("SELECT role FROM Users WHERE Name = @Name AND Password = @Password", connection))
                    {
                        command.Parameters.AddWithValue("@Name", username);
                        command.Parameters.AddWithValue("@Password", hashedPassword);

                        string role = (string)command.ExecuteScalar();

                        if (string.IsNullOrEmpty(role))
                        {
                            MessageBox.Show("Invalid username or password.");
                            return;
                        }

                        // odkázání na další formulář podle role uživatele
                        if (role.Equals("Admin"))
                        {
                            this.Hide();
                            AdminRedirect adminRedirect = new AdminRedirect();
                            adminRedirect.FormClosed += (s, args) => this.Close();
                            adminRedirect.Show();
                        }
                        else if (role.Equals("User"))
                        {
                            this.Hide();
                            userMain userMain = new userMain(username);
                            userMain.FormClosed += (s, args) => this.Close();
                            userMain.Owner = this;
                            userMain.Show();
                        }
                    }
                }
                catch (Exception ex)
                {
                    MessageBox.Show(ex.Message);
                }

            

            }
        }
        private string HashPassword(string password)
        {
            // zahashování hesla pomocí SHA256 algoritmu
            using (SHA256 sha256 = SHA256.Create())
            {
                byte[] bytes = sha256.ComputeHash(Encoding.UTF8.GetBytes(password));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                return builder.ToString();
            }
        }
    }
}
