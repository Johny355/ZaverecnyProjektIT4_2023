﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;
using System.Security.Cryptography;
using System.Text;
using System.Xml.Linq;
using System.Security.Policy;

namespace ZaverecnyProjektAmbroz
{
    public partial class userEdit : Form
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";
        private readonly SqlConnection conn;

        public userEdit()
        {
            InitializeComponent();
            conn = new SqlConnection(connectionString);
        }

        private void ExecuteNonQuery(SqlCommand command)
        {
            try
            {
                conn.Open();
                command.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }
        }

        private DataTable ExecuteQuery(SqlCommand command)
        {
            DataTable dataTable = new DataTable();

            try
            {
                conn.Open();
                SqlDataAdapter dataAdapter = new SqlDataAdapter(command);
                dataAdapter.Fill(dataTable);
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.Message);
            }
            finally
            {
                conn.Close();
            }

            return dataTable;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("None or invalid data have been provided");
                return;
            }

            // Hashing the password using SHA256
            string hashedPassword;
            using (SHA256 sha256Hash = SHA256.Create())
            {
                byte[] bytes = sha256Hash.ComputeHash(Encoding.UTF8.GetBytes(textBox2.Text));
                StringBuilder builder = new StringBuilder();
                for (int i = 0; i < bytes.Length; i++)
                {
                    builder.Append(bytes[i].ToString("x2"));
                }
                hashedPassword = builder.ToString();
            }

            // Inserting user into the database
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("INSERT INTO Users (ID, Name, Password, Role) VALUES (@ID, @Name, @Password, @Role)", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", int.Parse(textBox3.Text));
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);
                    cmd.Parameters.AddWithValue("@Password", hashedPassword);
                    cmd.Parameters.AddWithValue("@Role", checkBox1.Checked ? "Admin" : "User");
                    int rowsAffected = cmd.ExecuteNonQuery();

                    if (rowsAffected > 0)
                    {
                        MessageBox.Show("User added successfully!");
                    }
                    else
                    {
                        MessageBox.Show("User was not added.");
                    }
                }
            }

            conn.Close();
        }


        private void button2_Click(object sender, EventArgs e)
        {

            if (string.IsNullOrEmpty(textBox3.Text) || string.IsNullOrEmpty(textBox1.Text) || string.IsNullOrEmpty(textBox2.Text))
            {
                MessageBox.Show("None or invalid data have been provided");
                return;
            }

            // Update uživatele v databázi
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("UPDATE Users SET Name=@Name, Password=@Password, Role=@Role WHERE ID=@ID", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", int.Parse(textBox3.Text));
                    cmd.Parameters.AddWithValue("@Name", textBox1.Text);

                    // Hashování hesla
                    string password = textBox2.Text;
                    byte[] passwordBytes = Encoding.UTF8.GetBytes(password);
                    byte[] hashedBytes = SHA256.Create().ComputeHash(passwordBytes);
                    string hashedPassword = "";
                    StringBuilder builder = new StringBuilder();
                    for (int i = 0; i < hashedBytes.Length; i++)
                    {
                        builder.Append(hashedBytes[i].ToString("x2"));
                    }
                    hashedPassword = builder.ToString();

                    cmd.Parameters.AddWithValue("@Password", hashedPassword);
                    cmd.Parameters.AddWithValue("@Role", checkBox1.Checked ? "Admin" : "User");
                    ExecuteNonQuery(cmd);
                }
            }
            MessageBox.Show("Success");
        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("None or invalid data have been provided");
                return;
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("DELETE FROM Users WHERE ID=@ID", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", int.Parse(textBox3.Text));
                    ExecuteNonQuery(cmd);
                }
            }
            MessageBox.Show("Success");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text))
            {
                MessageBox.Show("None or invalid data have been provided");
                return;
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("SELECT * FROM Users WHERE ID=@ID", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", int.Parse(textBox3.Text));
                    dataGridView1.DataSource = ExecuteQuery(cmd);
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            SqlCommand cmd = new SqlCommand("SELECT * FROM Users", conn);
            dataGridView1.DataSource = ExecuteQuery(cmd);
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminRedirect adminRedirect = new AdminRedirect();
            adminRedirect.FormClosed += (s, args) => this.Close();
            adminRedirect.Show();
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.FormClosed += (s, args) => this.Close();
            login.Show();

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
