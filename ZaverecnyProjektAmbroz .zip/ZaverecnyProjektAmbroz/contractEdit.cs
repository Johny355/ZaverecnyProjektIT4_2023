﻿using System;
using System.Data;
using System.Data.SqlClient;
using System.Windows.Forms;

namespace ZaverecnyProjektAmbroz
{
    public partial class contractEdit : Form
    {
        private readonly string connectionString = "Data Source=(localdb)\\MSSQLLocalDB;Initial Catalog=dbProject;Integrated Security=True;Connect Timeout=30;Encrypt=False;TrustServerCertificate=False;ApplicationIntent=ReadWrite;MultiSubnetFailover=False";

        public contractEdit()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            // Add record
            string customer = textBox1.Text;
            int hours;
            if (!int.TryParse(textBox5.Text, out hours))
            {
                MessageBox.Show("Invalid value for Hours.");
                return;
            }
            string workType = textBox2.Text;
            string IDText = textBox3.Text;
            string username = textBox4.Text;
            int ID;
            try
            {
                ID = Convert.ToInt32(IDText);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid value for ID.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("INSERT INTO Records (ID, Customer, Hours, WorkType, Username, DateAdded) VALUES (@ID, @Customer, @Hours, @WorkType, @Username, @DateAdded)", connection);
                command.Parameters.AddWithValue("@ID", ID);
                command.Parameters.AddWithValue("@Customer", customer);
                command.Parameters.AddWithValue("@Hours", hours);
                command.Parameters.AddWithValue("@WorkType", workType);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@DateAdded", DateTime.Now.Date);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record added successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to add record.");
                }
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            // Update record
            string customer = textBox1.Text;
            int hours;
            if (!int.TryParse(textBox5.Text, out hours))
            {
                MessageBox.Show("Invalid value for Hours.");
                return;
            }
            string workType = textBox2.Text;
            string IDText = textBox3.Text;
            string username = textBox4.Text;
            int ID;
            try
            {
                ID = Convert.ToInt32(IDText);
            }
            catch (FormatException)
            {
                MessageBox.Show("Invalid value for ID.");
                return;
            }

            using (SqlConnection connection = new SqlConnection(connectionString))
            {
                connection.Open();
                SqlCommand command = new SqlCommand("UPDATE Records set Customer=@Customer, Hours=@Hours, WorkType=@WorkType, Username=@Username WHERE ID =@ID", connection);
                command.Parameters.AddWithValue("@ID", ID);
                command.Parameters.AddWithValue("@Customer", customer);
                command.Parameters.AddWithValue("@Hours", hours);
                command.Parameters.AddWithValue("@WorkType", workType);
                command.Parameters.AddWithValue("@Username", username);
                command.Parameters.AddWithValue("@DateAdded", DateTime.Now.Date);

                int rowsAffected = command.ExecuteNonQuery();
                if (rowsAffected > 0)
                {
                    MessageBox.Show("Record updated successfully.");
                }
                else
                {
                    MessageBox.Show("Failed to update record.");
                }
            }
        }

        private void button3_Click(object sender, EventArgs e)
        {
            // Remove record
            if (string.IsNullOrEmpty(textBox3.Text)) //pouze id
            {
                MessageBox.Show("None or invalid ID has been provided");
                return;
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("DELETE Records where ID=@ID", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", SqlDbType.Int).Value = int.Parse(textBox3.Text);
                    cmd.ExecuteNonQuery();
                }
            }
            MessageBox.Show("Success");
        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (string.IsNullOrEmpty(textBox3.Text)) //pouze id
            {
                MessageBox.Show("None or invalid ID has been provided");
                return;
            }
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("Select * from Records where ID = @ID", conn))
                {
                    cmd.Parameters.AddWithValue("@ID", SqlDbType.Int).Value = int.Parse(textBox3.Text);
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            using (SqlConnection conn = new SqlConnection(connectionString))
            {
                conn.Open();
                using (SqlCommand cmd = new SqlCommand("Select * from Records", conn))
                {
                    SqlDataAdapter da = new SqlDataAdapter(cmd);
                    DataTable dt = new DataTable();
                    da.Fill(dt);
                    dataGridView1.DataSource = dt;
                }
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            this.Hide();
            AdminRedirect adminRedirect = new AdminRedirect();
            adminRedirect.FormClosed += (s, args) => this.Close();
            adminRedirect.Show();
            
        }

        private void button7_Click(object sender, EventArgs e)
        {
            this.Hide();
            Login login = new Login();
            login.FormClosed += (s, args) => this.Close();
            login.Show();
        }
    }
}
